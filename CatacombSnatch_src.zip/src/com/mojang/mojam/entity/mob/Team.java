package com.mojang.mojam.entity.mob;

public class Team {
    public static final int Neutral = 0;
    public static final int Team1 = 1;
    public static final int Team2 = 2;
    public static final int MaxTeams = 3;
}
