package com.mojang.mojam.gui;


public class TitleMenuScreen {

    public TitleMenuScreen() {
        super();
    }

}
