package com.mojang.mojam.gui;

public interface ButtonListener {

    public void buttonPressed(Button button);
}
