package com.mojang.mojam.network;


public interface PacketListener {

    public void handle(Packet packet);

}
